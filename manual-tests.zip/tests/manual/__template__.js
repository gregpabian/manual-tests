function normalize( string ) {
	return string.replace( /[\n\r\s]+/g, ' ' );
}
