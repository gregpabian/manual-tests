@bender-ui: collapsed
@bender-tags: editor, mouse, list

1. Select a paragraph
2. Press "Insert/Remove Bulleted List" button
3. A list item should be created
4. Move the cursor to the beginning of the word "Praesentium" and press "ENTER" key
5. A new list item should be created
6. ....
