@bender-ui: collapsed
@bender-tags: editor, mouse, styles

1. Select "Lorem" word
2. Apply "Bold" - a text should become bold
3. Select a whole paragraph
4. Apply "Italic" - a paragraph should become italic
5. "Lorem" word in Bold should have both styles
6. Press "Finish" to complete the test
