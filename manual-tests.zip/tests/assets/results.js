/**
 * Copyright (c) 2014, CKSource - Frederico Knabben. All rights reserved.
 * Licensed under the terms of the MIT License (see LICENSE.md).
 */

var testResults = {
	list: '<ul class="dates"><li>19 years ago</li><li>19 years ago</li><li>lorem ispum dolor sit amet</li>' +
		'<li>19 years ago</li><li><span>foo</span></li></ul>',

	id: '<div id="date">19 years</div>'
};